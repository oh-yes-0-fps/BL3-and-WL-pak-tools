local stringx = require("pl.stringx")
local json = require("json")
local url = require("url")

LogError = {
    Ok = 0,
    Info = 1,
    Error = 2
}

--bl3logger is used to send log-messages to the webui
--bl3logger.Printf(LogError.Ok, "Log-Ok from Lua %s", "FormatParam")
--bl3logger.Println(LogError.Info, "Log-Info from Lua")
--bl3logger.Println(LogError.Error, "Log-Error from Lua")

hotfixCount = 0
moddedHotfixCount = 0
adjustedNum = 0
counter = 0

-- The main-handler for hotfix-modding
function VerificationHandler(responseBody)
    local response = mergeHotfixes(responseBody)
    responseBody = json.encode(response)
    if responseBody ~= nil then
        return responseBody
    end
    return nil
end

function ItemProxyHandler(origResp)
    local tradeResp = json.decode(origResp)
    if tradeResp ~= nil and customItemSerials ~= nil then
        for serial, v in pairs(customItemSerials) do
            local dateSent = GenerateItemDateSent()
            local Message = {
                trade_guid = "usermsg-" .. GenerateGUID(),
                from_player_id = "123",
                expires_at = GenerateItemExpiresDate(),
                date_sent = dateSent,
                trade_type = 1,
                item_payload = json.encode({
                    gear_serial_number = RemoveWhitespace(serial),
                    date_sent = dateSent
                }),
                item_identifier = "PlayerItem",
                platform = "shift",
            }
            customItemMails[Message.trade_guid] = serial
            table.insert(tradeResp.messages, Message)
        end
    end
    return json.encode(tradeResp)
end

function CreateGbxNewsData(headerText, iconName)
    local icon = iconName or "oakasset.frame.GenericImage1"
    local newsData = {
        id = 0,
        contents = {
            {
                header = headerText,
                body = "",
                summary = ""
            }
        },
        article_tags = {
            {
                value = icon,
                meta_tag = {
                    tag = "img_game_sm_noloc",
                    meta_tag_type = {
                        name = "general"
                    }
                }
            },
            {
                value = "https://github.com/c0dycode",
                meta_tag = {
                    tag = "url_learn_more_noloc",
                    meta_tag_type = {
                        name = "link"
                    }
                }
            },
        },
        availabilities = {
            {
                startTime = ""
            }
        }
    }
    return newsData
end

function NewsProxyHandler(originalResponse)
    if originalResponse == nil then
        return originalResponse
    end
    local news = json.decode(originalResponse)
    if news ~= nil then
        if currentSettings.ReplaceHotfixes then
            table.insert(news.data, CreateGbxNewsData("Modded Hotfixes: " .. moddedHotfixCount .. "/" .. moddedHotfixCount, "oakasset.frame.GenericImage2"))
        else
            table.insert(news.data, CreateGbxNewsData("Modded Hotfixes: " .. moddedHotfixCount .. "/" .. hotfixCount + moddedHotfixCount, "oakasset.frame.GenericImage2"))
        end
    end

    return json.encode(news)
end

-- getHotfixService
function getHotfixService(path)
    local tmpPath = path
    local params = {}
    local responseBody = ""
    if stringx.startswith(tmpPath, "[DISABLED] ") then
        tmpPath = stringx.replace(tmpPath, "[DISABLED] ", "")
    end

    if #RemoveWhitespace(tmpPath) == 0 then
        return params
    end

    if IsURL(tmpPath) then
        local valid, err = IsValidDirectURL(tmpPath)
        if err == "invalid GitHub URL, but we can fix it" then
            tmpPath = stringx.replace(tmpPath, "/blob/", "/raw/")
            valid = true
        end
        if valid then
            -- Remove any query parameters from path
            local url = url.parse(tmpPath)
            if url ~= nil then
                tmpPath = string.format("%s://%s%s", url.scheme, url.host, url.path)
            end

            local client = httpClient.New()
            if client ~= nil then
                req = httpClient.NewRequest("GET", tmpPath)
                if req ~= nil then
                    req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                    req.Header.Set("Accept-Language", "en-US,en;q=0.5")
                    req.Header.Set("Connection", "keep-alive")
                    req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0")
                    local response, err = client.Do(req)
                    if err ~= nil then
                        GoPrint("Error: " .. err)
                    end
                    if response ~= nil then
                        local responseHeader = httpResponse.GetHeader(response)
                        responseBody = httpResponse.GetBody(response)

                        local contentType = responseHeader["Content-Type"][1]
                        if contentType ~= nil then
                            if stringx.count(contentType, "application/x-gzip") > 0 or stringx.endswith(tmpPath, ".gz") then
                                local decompressed = DecompressGZip(responseBody)
                                if decompressed ~= nil and not IsJSON(decompressed) then
                                    local bytesReader = bytes.NewReader(decompressed)
                                    if bytesReader ~= nil then
                                        params = ProcessFile(bytesReader)
                                    else
                                        GoPrint("failed to get bytesReader")
                                    end
                                end
                            else
                                if not IsJSON(responseBody) then
                                    local bytesReader = bytes.NewReader(responseBody)
                                    if bytesReader ~= nil then
                                        params = ProcessFile(bytesReader)
                                    else
                                        GoPrint("failed to get bytesReader")
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    else
        if not FileExists(path) then
            bl3logger.Printf(LogError.Info, "File \"%s\" does not exist!", path)
            return custom
        end

        local fb = ioutil.ReadFile(path)
        if fb ~= nil then
            local r
            if stringx.endswith(path, ".gz") then
                local b, err = DecompressGZip(fb)
                if err ~= nil then
                    bl3logger.Printf(LogError.Error, "Failed to decompress gzip: %s\n", err)
                    return
                end
                r = bytes.NewReader(b)
            else
                r = bytes.NewReader(fb)
            end
            params = ProcessFile(r)
        end
    end
    -- If there is at least one parameter, that should mean that processing the given mod worked
    if #params > 0 then
        return params
    else
        -- If there are no params yet, check again if it actually is a raw json-mod-file and if so, return its parameters
        if IsJSON(responseBody) then
            local tmp = json.decode(responseBody)
            if tmp ~= nil then
                return tmp.parameters
            end
        end
    end
    return params
end

-- AppendUnique compares the currently available hotfixes and compares them to the ones you want to add.
-- Only entries where the key (e.g. SparkLevelPatchEntry737) and its value are exactly the same are exact duplicates
function AppendUnique(oldParams, paramsToAdd)
    local temp = {}
    for i, vNew in pairs(paramsToAdd) do
        local foundExactDupe = false
        for i2, vOld in pairs(oldParams) do
            if vOld.key == vNew.key then
                if vOld.value == vNew.value then
                    foundExactDupe = true
                    break
                else
                    local splitKey = stringx.split(vNew.key, "Entry")
                    vNew.key = string.format("%sEntry-Adjusted-%s-%08d", splitKey[1], splitKey[2], adjustedNum)
                    adjustedNum = adjustedNum + 1
                    break
                end
            end
        end
        if foundExactDupe == false then
            temp[#temp + 1] = vNew
        end
    end
    for i, v in pairs(temp) do
        table.insert(oldParams, v)
    end
	return oldParams
end

-- mergeHotfixes is used to effectively alter Gearboxes response
function mergeHotfixes(currentResponse)
    local current = {} --proxyService.GearboxServices
    local currentLen = 0
    local moddedLen = 0
    local custom = {} -- proxyService.Service
    local speedrunReplaced = false
    local speedrunHotfixesIndex = -1

    if currentResponse == nil then
        GoPrint("currentResponse was nil")
        return currentResponse
    end
    current = json.decode(currentResponse)
    if current == nil then
        bl3logger.Println(LogError.Error, "Failed to decode current hotfix response!")
        return currentResponse
    end

    local numServices = #current.services
    local i = 1
    while i <= numServices do
        if current.services[i] == nil then
            i = i + 1
        elseif current.services[i].service_name == "Micropatch" then
            currentLen = #current.services[i].parameters
            i = i + 1
            --GoPrint("Number of Gearbox Hotfixes: " .. numGbxHotfixes)
        elseif current.services[i].service_name == "TelemetryConfig" or
                current.services[i].service_name == "Zeppelin" or
                current.services[i].service_name == "Leviathan" or
                current.services[i].service_name == "Tribe" then
            --GoPrint("cleaning service: " .. current.services[i].service_name)
            table.remove(current.services, i)
        else
            i = i + 1
        end
    end

    if currentSettings.ReplaceHotfixes then
        for i, v in pairs(current.services) do
            if v.service_name == "Micropatch" then
                v.parameters = {}
            end
        end
    end

    for i = 1, #currentSettings.HotfixURLS do
        if currentSettings.SpeedrunMode
                and stringx.count(currentSettings.HotfixURLS[i], ".com/BLCM/bl3hotfixes/") == 0
                and stringx.count(currentSettings.HotfixURLS[i], "/point_in_time/") then
            ;;
        elseif stringx.startswith(currentSettings.HotfixURLS[i], "[DISABLED] ") then
            ;;
        else
            custom = getHotfixService(currentSettings.HotfixURLS[i])
            if currentSettings.SpeedrunMode == true then
                speedrunHash = HashModfile(currentSettings.HotfixURLS[i])
                speedrunReplaced = true
                speedrunHotfixesIndex = i
                bl3logger.Printf(LogError.Info, "Speedrun Hotfix info:\n[HASH]: %s\n[LINK]: %s", speedrunHash, currentSettings.HotfixURLS[speedrunHotfixesIndex])
            end
            for i2, v in pairs(current.services) do
                if v.service_name == "Micropatch" then
                    if currentLen == 0 then
                        currentLen = #v.parameters
                    end
                    if currentSettings.SpeedrunMode then
                        v.parameters = custom
                    else
                        print("Appending uniques")
                        print(json.encode(custom))
                        v.parameters = AppendUnique(v.parameters, custom)
                    end
                end
            end
        end
        moddedLen = moddedLen + #custom
        moddedHotfixCount = moddedLen
        if currentSettings.ReplaceHotfixes then
            hotfixCount = moddedLen
        else
            hotfixCount = currentLen
        end
    end
    if currentSettings.DumpAfterMerging then
        DumpJSON(json.encode(current))
    end
    return current
end

-- processFile reads the mod-file that has been provided and tries to extract/parse individual hotfixes into Parameters
function ProcessFile(reader)
    local params = {}
    local prefix = ""
    local pattern = "^%a+,%(%d+,%d+,%d+,[%a%p%d]*%),"

    local allLines = GetAllLinesFromReader(reader)
    for i = 1, #allLines do
        local str = allLines[i]
        if str == nil or #str == 0 then
            ;;
        elseif stringx.startswith(str, "#") or str == "" then
            ;;
        elseif stringx.endswith(str, "prefix") then
            GoPrint("string starting with \"prefix\": " .. str)
            local splitStr = stringx.split(str, ":")
            prefix = splitStr[1]
            prefix = RemoveWhitespace(prefix)
        else
            if string.match(str, pattern) == nil then
                print(str)
                GoPrint("string.match returned nil. Skipping to next line")
                ;;
            else
                local data = stringx.split(str, ",", 2)
                if #data >= 2 and #data % 1 == 0 then
                    local param = {}
                    param.key = string.format("%s-Custom-%s%08d", data[1], prefix, counter)
                    local lenPrev = 0
                    while true do
                        data[2] = TrimSuffix(data[2], "\r\n")
                        data[2] = TrimSuffix(data[2], "\r")
                        data[2] = TrimSuffix(data[2], "\n")
                        if lenPrev ~= #data[2] then
                            lenPrev = #data[2]
                        else
                            break
                        end
                    end
                    param.value = data[2]
                    params[#params + 1] = param
                    counter = counter + 1
                end
            end
        end
    end
    return params
end

function main()
    -- RegisterProxyResponseHandler is a helper function, registered from Go, to allow you to register your own handler(s) for specific response url-paths
    -- In this case we register a handler for "verification", which is part of the url-path if the game requests hotfixes
    local b = RegisterProxyResponseHandler("verification", VerificationHandler)
    if b == false then
        GoPrint("Failed to register ProxyResponseHandler for verification!")
    end
    b = RegisterProxyResponseHandler("v1/client/oak/players/item_trade", ItemProxyHandler)
    if b == false then
        GoPrint("Failed to register ProxyResponseHandler for ItemTrade!")
    end

    b = RegisterProxyResponseHandler("/api/v2/articles/oak", NewsProxyHandler)
    if b == false then
        GoPrint("Failed to register ProxyResponseHandler for News!")
    end

    -- Wonderlands
    b = RegisterProxyResponseHandler("/api/v2/articles/daffodil", NewsProxyHandler)
    if b == false then
        GoPrint("Failed to register ProxyResponseHandler for News!")
    end
end

-- call main to setup everything
main()