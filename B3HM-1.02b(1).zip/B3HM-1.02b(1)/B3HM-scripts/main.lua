local stringx = require("pl.stringx")

function HasPrefix(str, prefix)
    return str:sub(1, #prefix) == prefix
end

function HasSuffix(str, suffix)
    return suffix == "" or str:sub(-#suffix) == suffix
end

function TrimSuffix(str, suffix)
    str2, num = string.gsub(str, suffix .. "$", "")
    return str2
end

function TrimPrefix(str, prefix)
    str2, num = string.gsub(str, "^" .. str, prefix, "")
    return str2
end


